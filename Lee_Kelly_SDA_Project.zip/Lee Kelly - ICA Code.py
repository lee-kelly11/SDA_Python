## Secure Data Acquisition Project Code
## Lee Patrick Kelly
## Teesside University, UK
## 22-02-2021

## !! DO NOT COPY OR USE THIS CODE !!

"""
This Program is for the Secure Data Acquistion In Course Assessment - Part 1

Please be aware that:
This program could take a long time to run due to the data processing invloved.
This could take anywere up to 5 minutes to load and run fully.

DO NOT USE OR COPY ANY OF THIS CODE YOURSELF - THIS IS TO VIEW ONLY!

"""

# This imports the necessary libraries
import pandas as pd
import matplotlib.pyplot as plt


# This import the data and store it in a dataframe
data_original = pd.read_excel ("data/kddcup_corrected_dataset.xlsx", 
                              index_col = None, header = None)



## Cleaning the data



# To add column titles to the data
data_original.columns = [
    "duration", "protocol_type", "service", "flag","src_bytes", "dst_bytes",
    "land", "wrong_fragment","urgent", "hot", "num_failed_logins", 
    "logged_in", "num_compromised", "root_shell", "su_attempted","num_root",
    "num_file_creations", "num_shells", "num_access_files",
    "num_outbound_cmds", "is_host_login", "is_guest_login", "count", 
    "srv_count", "serror_rate", "srv_serror_rate", "rerror_rate", 
    "srv_rerror_rate", "same_srv_rate", "diff_srv_rate", "srv_diff_host_rate",
    "dst_host_count", "dst_host_srv_count", "dst_host_same_srv_rate", 
    "dst_host_diff_srv_rate", "dst_host_same_src_port_rate", 
    "dst_host_srv_diff_host_rate", "dst_host_serror_rate",
    "dst_host_srv_serror_rate", "dst_host_rerror_rate", 
    "dst_host_srv_rerror_rate", "security_attack_type"
    ]

data_with_titles = data_original

# This deletes unnecessary columns
data_deleted_land = data_with_titles.drop(columns=['land'])
data_deleted_hostlogin = data_deleted_land.drop(columns=['is_host_login'])
data_deleted_suattempted =data_deleted_hostlogin.drop(columns=['su_attempted'])

data_deleted_columns = data_deleted_suattempted

# This takes all of the 'unknown' values and replaces them with 'nan'
data_deleted_unknown = data_deleted_columns.mask(data_deleted_columns.eq('unknown'))
# This then drops the 'nan' values from the dataset
data_deleted = data_deleted_unknown.dropna()


## Sorting the Data


# Sort the dataset via Protocol Type
data_sorted_via_protocol = data_deleted.sort_values(by=['protocol_type'])

# Sorting the data via Security Attack Type
data_sorted_via_connection = data_deleted.sort_values(by=['security_attack_type'])

#Shortning the dataframe name
data_sorted = data_sorted_via_connection



## Data Analysis



# Using the newly cleaned and sorted dataframe (via type of security attack),
# We can use .head() & .tail() to display a sample of the datset

# To see and print out the top 6 rows of the data
print("\n","Top 6 Rows of the Dataset:")
print(data_sorted.head(6))

# To see and print out the top 4 rows of the data
print("\n", "Top 4 Rows of the Dataset:")
print(data_sorted.head(4))

# To see and print out the top 8 rows of the data
print("\n", "Top 8 Rows of the Dataset:")
print(data_sorted.head(8))

# To see and print out the bottom 10 rows of the data
print("\n", "Bottom 10 Rows of the Dataset:")
print(data_sorted.tail(10))

# To see and print out the bottom 3 rows of the data
print("\n", "Bottom 3 Rows of the Dataset:")
print(data_sorted.tail(3))

# To see and print out the bottom 7 rows of the data
print("\n", "Bottom 7 Rows of the Dataset:")
print(data_sorted.tail(7))


## To get descriptive data 


# Title
print("\n", "Descriptive Data", "\n")

# Using .max()
print("The most amount of files accessed at any one time was:",
      data_sorted["num_access_files"].max())

# Using .min()
print("The minimum amount of dst host count was:",
      data_sorted["dst_host_count"].min())

# Using .mode()
print("The most common Protocol Type is", 
      data_sorted["protocol_type"].mode())

# Using .mean()
print("The average number of data bytes from source to destination was:", 
      data_sorted["dst_bytes"].mean())

# Using .median()
print("The medium number of data bytes from source to destination was:", 
      data_sorted["dst_bytes"].median())

print("The medium number of data bytes from destination to source was:", 
      data_sorted["src_bytes"].median())

# Using .describe()
print ("Information about the number of connections to the same service in 2 secs:")
print (data_sorted["srv_count"].describe())

print ("Information about the number of connections to the same host in 2 secs:")
print (data_sorted["count"].describe())



## Charts and Graphs


# Chart 1: Pie Chart 1:
# A Pie Chart to Show the Top 5 Types of Secuirty Attacks


# To count the amounts of each attack
attacks = data_sorted.groupby(['security_attack_type']).size()

# To create  and display the pie chart
labels = ['Smurf\n'+'(57.4%)', 'Neptune\n'+'(21.9%)', 'Normal\n'+'(19.9%)',
          'Back (0.5%)\n'+'Satan (0.3%)',''
          ]
sizes = [attacks['smurf.'], attacks['neptune.'], attacks['normal.'],
         attacks['back.'], attacks['satan.']
         ]
colours = ['#0033cc', '#0099ff', '#33ccff', 'm', 'red',]
explode = (0,0,0,0.08,0.08)
patches, texts = plt.pie(sizes, shadow=True, colors=colours, 
                         explode=explode, startangle=295, counterclock = False,
                         wedgeprops={'linewidth': 4, 'linestyle': 'solid',
                                     'antialiased': True}, labels=labels
                         )
plt.axis('equal')
plt.margins(0.05)
plt.tight_layout()
plt.title("A Pie Chart Showing the Top 5\n" + " Types of Secuirty Attacks ",
          bbox={'facecolor':'gainsboro', 'pad':5}
          )
plt.show()



# Chat 2: Pie Chart 2:
# % of The Top 3 Types of Attacks Compared to the % of All Other Attacks


# To count the amounts of each attack
attacks = data_sorted.groupby(['security_attack_type']).size()

# To create a 'Other' cateogroy for smaller attacks
other = data_sorted['security_attack_type'].count() - (
    attacks['smurf.'] + attacks['neptune.'] + attacks['normal.']
    )

# To create and display the pie chart
labels = ['Smurf\n'+'(56.8%)', 'Neptune\n'+'(21.7%)', 'Normal\n'+'(19.7%)',
          'All Other Types\n' + '(1.8%)'
         ]
sizes = [attacks['smurf.'], attacks['neptune.'], attacks['normal.'], other]
explode = (0,0,0,0.08)
colours = ['crimson', 'darkorange', 'deepskyblue', 'darkgreen']
patches, texts = plt.pie(sizes, shadow=True, colors=colours, explode=explode,
                         startangle=295, counterclock = False,
                         wedgeprops={'linewidth': 4, 'linestyle': 'solid',
                                     'antialiased': True}, labels=labels
                         )
plt.axis('equal')
plt.tight_layout()
plt.title("A Pie Chart Showing the Percentage of the Top 3\n" 
          + "Types of Attacks Compared to the Percentage of All Other Attacks",
          bbox={'facecolor':'gainsboro', 'pad':5} )
plt.show()



# Chart 3: Pie Chart 3:
# A Pie Chart to show the Percentage of 'Other' Types of Attacks


# To count the amounts of each attack
attacks = data_sorted.groupby(['security_attack_type']).size()
# To create a 'Other' cateogroy for smaller attacks
under30 = data_sorted['security_attack_type'].count() - (
    attacks['smurf.'] + attacks['neptune.'] + attacks['normal.'] + 
    [attacks['back.'] + attacks['satan.'] + attacks['ipsweep.'] + 
     attacks['portsweep.'] + attacks['warezclient.'] + attacks['teardrop.'] + 
     attacks['pod.'] + attacks['nmap.'] + attacks['guess_passwd.'] + 
     attacks['buffer_overflow.']
     ]
    )

# To create  and display the pie chart
labels = ['Back \n'+'(25.3%)', 'Satan\n'+'(18.2%)', 'IP Sweep (14.3%)',
          'Port Sweep (11.9%)', 'Warezcleint\n'+'(11.7%)', 
          'Teardrop\n'+'(11.2%)', 'Pod (3.0%)','',
          '   Nmap (2.7%)\n' + ' Guess password (0.6%)\n' +
          '<=30 Connections (1.1%)',''
          ]
sizes = [attacks['back.'], attacks['satan.'], attacks['ipsweep.'], 
         attacks['portsweep.'], attacks['warezclient.'], attacks['teardrop.'],
         attacks['pod.'], attacks['nmap.'], attacks['guess_passwd.'], under30
         ]
colours = ['orangered','dodgerblue','lawngreen','darkgoldenrod','c',
           'darkmagenta','indigo','coral', 'maroon', 'black'
          ]
patches, texts = plt.pie(sizes, shadow=True, colors=colours, 
                         startangle=295, counterclock = False,
                         wedgeprops={'linewidth': 4, 'linestyle': 'solid',
                                     'antialiased': True}, labels=labels
                         )
plt.axis('equal')
plt.tight_layout()
plt.title("A Pie Chart Showing the Percentage of Types of Attacks\n" + 
          "(Excluding the Top 3)", bbox={'facecolor':'gainsboro', 'pad':5}
          )
plt.show()



# Chart 4: Bar Chart 1: 
# A Bar Chart to Show the Amount of Successful and Not Successful Logins 


# To add colour to the chart 
colour = ['#D31B1B', 'limegreen']

# To create the bar chart 
data_sorted['logged_in'].value_counts().plot(kind='bar', color=colour,
                                             figsize=(10,8)                                             
                                             )

# Title and Labels
plt.title(
    "The Amount of Successful and Not Successful Logins within the dataset"
    )
plt.xlabel("Category\n" + "(0 = Not Successful   |   1 = Successful )")
plt.ylabel("Frequency")

# To Display the Bar Chart
plt.show()



# Chart 5: Bar Chart 2:
# A Bar Chart to show the Amount of Attacks using Different Types of Flags

# To Add the Colour to the Bars
colour = ['chocolate', 'y', 'mediumspringgreen', 'slateblue', 'darkkhaki',
          'silver'
          ]

# To create the bar chart from the dataset
data_sorted['flag'].value_counts().plot(kind='bar', color=colour,
                                        figsize=(10,8)
                                        )

# To display the bar chart with titles and labels
plt.title("A Bar Chart showing the Amount of Attacks Using Different Types of Flags")
plt.xlabel("Flag Types")
plt.ylabel("Amount of Connections")
# To disaply the chart
plt.show()



# Chart 6: Bar Chart 3:
# A Bar Chart to Show the Amount of Times Each Protocol Type was Used


# To add colour to the bars
colour = ['#434343', '#F94607', '#6D0F62']

# To create the bar chart from the dataset
data_sorted['protocol_type'].value_counts().plot(kind='bar', color=colour,
                                                 figsize=(10,8)
                                                 )

# To add a title and labels to the bar chart and display it
plt.title("A Bar Chart to Show the Amount of Times Each Protocol Type was Used")
plt.xlabel("Protocol Type")
plt.ylabel("Amount of Connections Made")
plt.show() 


## End Of Program